=== NOTES ===

Original Readme File by Group-Finity

=== END NOTES ===




2.1.0 read me file Shimeji

==== How to Start ==== 

Double Click the Shimeji icon (Shimeji.exe).

==== How to quit ==== 

Right-click the tray icon of Shimeji, Select "Bye bye."

==== How to Uninstall ==== 

- From the installer -

Remove the Shimeji from the Add or Remove Programs in Control Panel.

- From the zip -

Delete the unzipped folder.

==== Source ====

Programmers may feel free to use the source.
Follow the zlib/libpng licenses.

==== Library ====

lib / jna.jar and lib / examples.jar of the JNA library.
JNA follows the LGPL.

==== FAQ ====

FAQ is the official site.
http://www.group-finity.com/Shimeji/

==== What's New ====

Aug 16, 2010

v 2.1.2

- Fixed Shimeji in multi-monitor mirrored mode.
� Windows 2000 environment fix.

December 23, 2009

v 2.1.1

� Fixed multi-monitor support

Tuesday, December 01, 2009

v 2.1.0

- Added support for Marutemonita environment.
Come out on their own separate from the monitor, so Shimeji are not bothersome. (When you fall outside of the growth has come.)
Can be placed by dropping.
- Fixed a problem that time would go faster in a particular environment.
Shimji are now interested in chrome and firefox

May 21, 2009

v 2.0.0