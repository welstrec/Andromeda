//****************
// ���[�V�����Đ�
//****************

#ifndef		_MOTIONPLAYER_H_
#define		_MOTIONPLAYER_H_

#include	"VMDMotion.h"

class cPMDModel;

class cMotionPlayer
{
	private :
		cPMDModel		*m_pPMDModel;
		cVMDMotion		*m_pVMDMotion;

		cPMDBone		**m_ppBoneList;
		cPMDFace		**m_ppFaceList;

		float			m_fOldFrame,
						m_fFrame;
		bool			m_bLoop;		// ���[�V���������[�v���邩�ǂ���

		float			m_fInterpolateFrameMax;	// ���[�V������ԗp
		float			m_fInterpolateFrameNow;


		void getMotionPosRot( const MotionDataList *pMotionData, float fFrame, Vector3 *pvec3Pos, Vector4 *pvec4Rot );
		float getFaceRate( const FaceDataList *pFaceData, float fFrame );

	public :
		cMotionPlayer( void );
		~cMotionPlayer( void );

		void setup( cPMDModel *pPMDModel, cVMDMotion *pMotion, bool bLoop, float fInterpolateFrame );

		bool update( float fElapsedFrame );

		void clear( void );

		// 2009/07/15 Ru--en
		void rewind( void );
		void setLoop( bool bLoop );

};

#endif	// _MOTIONPLAYER_H_
