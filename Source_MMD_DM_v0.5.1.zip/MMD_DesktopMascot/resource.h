//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MMD_DesktopMascot.rc
//
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDC_MENU                        109
#define IDI_MMDDM_ICON                  132
#define IDS_CLASSNAME                   136
#define IDS_APP_TITLE                   137
#define IDM_OPEN_MODEL                  32788
#define IDM_OPEN_MOTION                 32789
#define IDM_SCLAE_UP                    32790
#define IDM_SCALE_DOWN                  32791
#define IDM_SCALE_200                   32792
#define IDM_SCALE_100                   32793
#define IDM_SCALE_50                    32794
#define IDM_LOOKATME                    32802
#define IDM_TOPMOST                     32807
#define IDM_ROT_LEFT                    32823
#define IDM_ROT_UP                      32825
#define IDM_ROT_RIGHT                   32826
#define IDM_ROT_DOWN                    32827
#define IDM_MOV_RIGHT                   32828
#define IDM_MOV_LEFT                    32829
#define IDM_MOV_DOWN                    32831
#define IDM_MOV_UP                      32832
#define IDM_POS_RESET                   32837
#define IDM_FPS_30                      32847
#define IDM_FPS_15                      32848
#define IDM_FPS_5                       32849
#define IDM_FPS_10                      32851
#define IDM_CANVAS_FULL                 32859
#define IDM_CANVAS_800                  32860
#define IDM_CANVAS_600                  32861
#define IDM_CANVAS_400                  32862
#define IDM_CANVAS_200                  32863
#define IDM_POPUP_MENU                  32871
#define IDM_FPS_60                      32876
#define IDM_SHOW_FPS                    32878
#define IDM_DEBUG                       32879
#define IDM_ENABLE_PHYSICS              32882
#define IDM_POSEBLEND                   32887
#define ID_FILE_WINDOWFOLLOWSMODEL      32891
#define IDM_MOVINGWINDOW                32892
#define IDM_SHOWFPS                     32897
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32898
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
